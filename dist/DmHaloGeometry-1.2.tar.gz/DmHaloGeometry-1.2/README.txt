Package to solve geometry problems with particle data from dark matter simulations.

Download using "pip install DmHaloGeometry==0.1"
